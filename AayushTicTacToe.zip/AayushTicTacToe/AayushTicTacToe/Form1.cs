﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AayushTicTacToe
{
    public partial class Form1 : Form
    {
        private bool turns; // A boolean variable to track whose turn it is (true for X, false for O)
        int[,] image = new int[3, 3]; // A 2D array to represent the Tic-Tac-Toe board
        private int moves; // Count of the total moves played
        public Form1()
        {
            InitializeComponent();
            Restart();
        }

        private void ShowPictures(PictureBox picture)
        {
            // Display X or O in the clicked PictureBox, depending on whose turn it is

            if (turns == true)
            {
                picture.Image = Properties.Resources.x;
                turns = false;
            }
            else
            {
                picture.Image = Properties.Resources.o;
                turns = true;
            }
            picture.Enabled = false;  // Disable the PictureBox to prevent further clicks
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (image[0, 0] != 0)
                return; // Return if the cell is already occupied
            image[0, 0] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox1); // Update the PictureBox with X or O
            CheckImages(); // Check if the game has been won or tied
            moves++;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (image[0, 1] != 0)
                return;
            image[0, 1] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox2);
            CheckImages();
            moves++;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (image[0, 2] != 0)
                return;
            image[0, 2] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox3);
            CheckImages();
            moves++;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (image[1, 0] != 0)
                return;
            image[1, 0] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox4);
            CheckImages();
            moves++;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (image[1, 1] != 0)
                return;
            image[1, 1] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox5);
            CheckImages();
            moves++;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (image[1, 2] != 0)
                return;
            image[1, 2] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox6);
            CheckImages();
            moves++;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (image[2, 0] != 0)
                return;
            image[2, 0] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox7);
            CheckImages();
            moves++;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (image[2, 1] != 0)
                return;
            image[2, 1] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox8);
            CheckImages();
            moves++;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (image[2, 2] != 0)
                return;
            image[2, 2] = (turns == true) ? 1 : -1;

            ShowPictures(pictureBox9);
            CheckImages();
            moves++;
        }
        private void CheckImages()
        {
            int D1 = 0;
            int D2 = 0;
            int[] col = new int[3];
            int[] row = new int[3];

            // Check for wins or a tie by examining rows, columns, and diagonals
            for (int i = 0; i < 3; i++)
            {
                row[i] = 0;
                col[i] = 0;
                for (int j = 0; j < 3; j++)
                {
                    row[i] = row[i] + image[i, j];
                    col[i] = col[i] + image[j, i];

                    if (i == j)
                    {
                        D1 = D1 + image[i, j];
                    }
                    if (i + j == 2)
                    {
                        D2 = D2 + image[i, j];
                    }

                }
            }

            if (moves == 9)
            {
                MessageBox.Show("It's a tie!", "Game Over", MessageBoxButtons.OK);
                Restart(); // If all cells are filled and no one has won, it's a tie.
                return;
            }

            if (D1 == -3 || D2 == -3)
            {
                MessageBox.Show("Player O wins!", "Game Over", MessageBoxButtons.OK);
                Restart(); // Player O has won with the combination of cells.
            }
            else if (D1 == 3 || D2 == 3)
            {
                MessageBox.Show("Player X wins!", "Game Over", MessageBoxButtons.OK);
                Restart();// Player X has won with the combination of cells.
            }

            for (int i = 0; i < 3; i++)
            {
                if (row[i] == -3 || col[i] == -3)
                {
                    MessageBox.Show("Player O wins!", "Game Over", MessageBoxButtons.OK);
                    Restart(); // Player O has won with a row or column.
                }
                else if (row[i] == 3 || col[i] == 3)
                {
                    MessageBox.Show("Player X wins!", "Game Over", MessageBoxButtons.OK);
                    Restart(); // Player X has won with a row or column.

                }
            }
        }

        private void Restart()
        {
            // Reset the game board and PictureBox elements for a new game
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    image[i, j] = 0;
                }
            }

            // Reset the PictureBox elements to empty and enable them for a new game
            foreach (Control control in this.Controls)
            {
                if (control is PictureBox)
                {
                    ((PictureBox)control).Image = null;
                    ((PictureBox)control).Enabled = true;
                }
            }

            turns = true; // Set the first move to X
            moves = 0; // Reset the move count
        }
    }
}
